﻿namespace dbmid_project
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            sidebrpnl = new Panel();
            linkLabel6 = new LinkLabel();
            linkLabel15 = new LinkLabel();
            linkLabel16 = new LinkLabel();
            linkLabel14 = new LinkLabel();
            label9 = new Label();
            linkLabel13 = new LinkLabel();
            label7 = new Label();
            linkLabel12 = new LinkLabel();
            linkLabel7 = new LinkLabel();
            label3 = new Label();
            linkLabel10 = new LinkLabel();
            linkLabel9 = new LinkLabel();
            linkLabel8 = new LinkLabel();
            label2 = new Label();
            linkLabel5 = new LinkLabel();
            linkLabel4 = new LinkLabel();
            linkLabel3 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            linkLabel1 = new LinkLabel();
            label4 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            pnlContent = new Panel();
            sidebrpnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // sidebrpnl
            // 
            sidebrpnl.BackColor = Color.SteelBlue;
            sidebrpnl.Controls.Add(linkLabel6);
            sidebrpnl.Controls.Add(linkLabel15);
            sidebrpnl.Controls.Add(linkLabel16);
            sidebrpnl.Controls.Add(linkLabel14);
            sidebrpnl.Controls.Add(label9);
            sidebrpnl.Controls.Add(linkLabel13);
            sidebrpnl.Controls.Add(label7);
            sidebrpnl.Controls.Add(linkLabel12);
            sidebrpnl.Controls.Add(linkLabel7);
            sidebrpnl.Controls.Add(label3);
            sidebrpnl.Controls.Add(linkLabel10);
            sidebrpnl.Controls.Add(linkLabel9);
            sidebrpnl.Controls.Add(linkLabel8);
            sidebrpnl.Controls.Add(label2);
            sidebrpnl.Controls.Add(linkLabel5);
            sidebrpnl.Controls.Add(linkLabel4);
            sidebrpnl.Controls.Add(linkLabel3);
            sidebrpnl.Controls.Add(linkLabel2);
            sidebrpnl.Controls.Add(linkLabel1);
            sidebrpnl.Controls.Add(label4);
            sidebrpnl.Controls.Add(label1);
            sidebrpnl.Controls.Add(pictureBox1);
            sidebrpnl.Location = new Point(1, 1);
            sidebrpnl.Name = "sidebrpnl";
            sidebrpnl.Size = new Size(365, 1164);
            sidebrpnl.TabIndex = 4;
            // 
            // linkLabel6
            // 
            linkLabel6.ActiveLinkColor = Color.MidnightBlue;
            linkLabel6.AutoSize = true;
            linkLabel6.DisabledLinkColor = Color.Black;
            linkLabel6.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel6.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel6.LinkColor = Color.Black;
            linkLabel6.Location = new Point(10, 717);
            linkLabel6.MinimumSize = new Size(375, 23);
            linkLabel6.Name = "linkLabel6";
            linkLabel6.Padding = new Padding(50, 0, 0, 0);
            linkLabel6.Size = new Size(375, 23);
            linkLabel6.TabIndex = 33;
            linkLabel6.TabStop = true;
            linkLabel6.Text = "Add new Duties";
            linkLabel6.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel6.VisitedLinkColor = Color.Black;
            linkLabel6.LinkClicked += linkLabel6_LinkClicked;
            // 
            // linkLabel15
            // 
            linkLabel15.ActiveLinkColor = Color.MidnightBlue;
            linkLabel15.AutoSize = true;
            linkLabel15.DisabledLinkColor = Color.Black;
            linkLabel15.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel15.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel15.LinkColor = Color.Black;
            linkLabel15.Location = new Point(10, 294);
            linkLabel15.MinimumSize = new Size(375, 23);
            linkLabel15.Name = "linkLabel15";
            linkLabel15.Padding = new Padding(50, 0, 0, 0);
            linkLabel15.Size = new Size(375, 23);
            linkLabel15.TabIndex = 32;
            linkLabel15.TabStop = true;
            linkLabel15.Text = "ITEC Editions";
            linkLabel15.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel15.VisitedLinkColor = Color.Black;
            linkLabel15.LinkClicked += linkLabel15_LinkClicked_1;
            // 
            // linkLabel16
            // 
            linkLabel16.ActiveLinkColor = Color.MidnightBlue;
            linkLabel16.AutoSize = true;
            linkLabel16.DisabledLinkColor = Color.Black;
            linkLabel16.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel16.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel16.LinkColor = Color.Black;
            linkLabel16.Location = new Point(10, 1009);
            linkLabel16.MinimumSize = new Size(375, 23);
            linkLabel16.Name = "linkLabel16";
            linkLabel16.Padding = new Padding(50, 0, 0, 0);
            linkLabel16.Size = new Size(375, 23);
            linkLabel16.TabIndex = 31;
            linkLabel16.TabStop = true;
            linkLabel16.Text = "Learderboard";
            linkLabel16.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel16.VisitedLinkColor = Color.Black;
            linkLabel16.LinkClicked += linkLabel16_LinkClicked;
            // 
            // linkLabel14
            // 
            linkLabel14.ActiveLinkColor = Color.MidnightBlue;
            linkLabel14.AutoSize = true;
            linkLabel14.DisabledLinkColor = Color.Black;
            linkLabel14.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel14.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel14.LinkColor = Color.Black;
            linkLabel14.Location = new Point(10, 978);
            linkLabel14.MinimumSize = new Size(375, 23);
            linkLabel14.Name = "linkLabel14";
            linkLabel14.Padding = new Padding(50, 0, 0, 0);
            linkLabel14.Size = new Size(375, 23);
            linkLabel14.TabIndex = 29;
            linkLabel14.TabStop = true;
            linkLabel14.Text = "Record Results";
            linkLabel14.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel14.VisitedLinkColor = Color.Black;
            linkLabel14.LinkClicked += linkLabel14_LinkClicked;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.DodgerBlue;
            label9.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(0, 944);
            label9.MinimumSize = new Size(375, 23);
            label9.Name = "label9";
            label9.Size = new Size(375, 23);
            label9.TabIndex = 28;
            label9.Text = "Competition Results";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // linkLabel13
            // 
            linkLabel13.ActiveLinkColor = Color.MidnightBlue;
            linkLabel13.AutoSize = true;
            linkLabel13.DisabledLinkColor = Color.Black;
            linkLabel13.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel13.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel13.LinkColor = Color.Black;
            linkLabel13.Location = new Point(10, 904);
            linkLabel13.MinimumSize = new Size(375, 23);
            linkLabel13.Name = "linkLabel13";
            linkLabel13.Padding = new Padding(50, 0, 0, 0);
            linkLabel13.Size = new Size(375, 23);
            linkLabel13.TabIndex = 24;
            linkLabel13.TabStop = true;
            linkLabel13.Text = "Budget Summary";
            linkLabel13.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel13.VisitedLinkColor = Color.Black;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.DodgerBlue;
            label7.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(-2, 789);
            label7.MinimumSize = new Size(375, 23);
            label7.Name = "label7";
            label7.Size = new Size(375, 23);
            label7.TabIndex = 27;
            label7.Text = "Finances";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            label7.Click += label7_Click;
            // 
            // linkLabel12
            // 
            linkLabel12.ActiveLinkColor = Color.MidnightBlue;
            linkLabel12.AutoSize = true;
            linkLabel12.DisabledLinkColor = Color.Black;
            linkLabel12.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel12.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel12.LinkColor = Color.Black;
            linkLabel12.Location = new Point(10, 747);
            linkLabel12.MinimumSize = new Size(375, 23);
            linkLabel12.Name = "linkLabel12";
            linkLabel12.Padding = new Padding(50, 0, 0, 0);
            linkLabel12.Size = new Size(375, 23);
            linkLabel12.TabIndex = 26;
            linkLabel12.TabStop = true;
            linkLabel12.Text = "Track Duties";
            linkLabel12.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel12.VisitedLinkColor = Color.Black;
            linkLabel12.LinkClicked += linkLabel12_LinkClicked;
            // 
            // linkLabel7
            // 
            linkLabel7.ActiveLinkColor = Color.MidnightBlue;
            linkLabel7.AutoSize = true;
            linkLabel7.DisabledLinkColor = Color.Black;
            linkLabel7.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel7.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel7.LinkColor = Color.Black;
            linkLabel7.Location = new Point(10, 868);
            linkLabel7.MinimumSize = new Size(375, 23);
            linkLabel7.Name = "linkLabel7";
            linkLabel7.Padding = new Padding(50, 0, 0, 0);
            linkLabel7.Size = new Size(375, 23);
            linkLabel7.TabIndex = 23;
            linkLabel7.TabStop = true;
            linkLabel7.Text = "Track Registration Fees";
            linkLabel7.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel7.VisitedLinkColor = Color.Black;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.DodgerBlue;
            label3.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(-2, 677);
            label3.MinimumSize = new Size(375, 23);
            label3.Name = "label3";
            label3.Size = new Size(375, 23);
            label3.TabIndex = 22;
            label3.Text = "Duties Management";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // linkLabel10
            // 
            linkLabel10.ActiveLinkColor = Color.MidnightBlue;
            linkLabel10.AutoSize = true;
            linkLabel10.DisabledLinkColor = Color.Black;
            linkLabel10.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel10.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel10.LinkColor = Color.Black;
            linkLabel10.Location = new Point(10, 833);
            linkLabel10.MinimumSize = new Size(375, 23);
            linkLabel10.Name = "linkLabel10";
            linkLabel10.Padding = new Padding(50, 0, 0, 0);
            linkLabel10.Size = new Size(375, 23);
            linkLabel10.TabIndex = 24;
            linkLabel10.TabStop = true;
            linkLabel10.Text = "Add Transaction";
            linkLabel10.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel10.VisitedLinkColor = Color.Black;
            linkLabel10.LinkClicked += linkLabel10_LinkClicked;
            // 
            // linkLabel9
            // 
            linkLabel9.ActiveLinkColor = Color.MidnightBlue;
            linkLabel9.AutoSize = true;
            linkLabel9.DisabledLinkColor = Color.Black;
            linkLabel9.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel9.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel9.LinkColor = Color.Black;
            linkLabel9.Location = new Point(10, 607);
            linkLabel9.MinimumSize = new Size(375, 23);
            linkLabel9.Name = "linkLabel9";
            linkLabel9.Padding = new Padding(50, 0, 0, 0);
            linkLabel9.Size = new Size(375, 23);
            linkLabel9.TabIndex = 21;
            linkLabel9.TabStop = true;
            linkLabel9.Text = "Add Committee to an event";
            linkLabel9.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel9.VisitedLinkColor = Color.Black;
            linkLabel9.LinkClicked += linkLabel9_LinkClicked;
            // 
            // linkLabel8
            // 
            linkLabel8.ActiveLinkColor = Color.MidnightBlue;
            linkLabel8.AutoSize = true;
            linkLabel8.DisabledLinkColor = Color.Black;
            linkLabel8.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel8.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel8.LinkColor = Color.Black;
            linkLabel8.Location = new Point(10, 640);
            linkLabel8.MinimumSize = new Size(375, 23);
            linkLabel8.Name = "linkLabel8";
            linkLabel8.Padding = new Padding(50, 0, 0, 0);
            linkLabel8.Size = new Size(375, 23);
            linkLabel8.TabIndex = 20;
            linkLabel8.TabStop = true;
            linkLabel8.Text = "Edit Committees";
            linkLabel8.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel8.VisitedLinkColor = Color.Black;
            linkLabel8.LinkClicked += linkLabel8_LinkClicked;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.DodgerBlue;
            label2.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(-2, 568);
            label2.MinimumSize = new Size(375, 23);
            label2.Name = "label2";
            label2.Size = new Size(375, 23);
            label2.TabIndex = 18;
            label2.Text = "Committees And Roles";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // linkLabel5
            // 
            linkLabel5.ActiveLinkColor = Color.MidnightBlue;
            linkLabel5.AutoSize = true;
            linkLabel5.DisabledLinkColor = Color.Black;
            linkLabel5.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel5.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel5.LinkColor = Color.Black;
            linkLabel5.Location = new Point(11, 468);
            linkLabel5.MinimumSize = new Size(375, 23);
            linkLabel5.Name = "linkLabel5";
            linkLabel5.Padding = new Padding(50, 0, 0, 0);
            linkLabel5.Size = new Size(375, 23);
            linkLabel5.TabIndex = 16;
            linkLabel5.TabStop = true;
            linkLabel5.Text = "Register Participants";
            linkLabel5.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel5.VisitedLinkColor = Color.Black;
            linkLabel5.LinkClicked += linkLabel5_LinkClicked;
            // 
            // linkLabel4
            // 
            linkLabel4.ActiveLinkColor = Color.MidnightBlue;
            linkLabel4.AutoSize = true;
            linkLabel4.DisabledLinkColor = Color.Black;
            linkLabel4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel4.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel4.LinkColor = Color.Black;
            linkLabel4.Location = new Point(10, 500);
            linkLabel4.MinimumSize = new Size(375, 23);
            linkLabel4.Name = "linkLabel4";
            linkLabel4.Padding = new Padding(50, 0, 0, 0);
            linkLabel4.Size = new Size(375, 23);
            linkLabel4.TabIndex = 15;
            linkLabel4.TabStop = true;
            linkLabel4.Text = "Registrations Type and Fees";
            linkLabel4.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel4.VisitedLinkColor = Color.Black;
            linkLabel4.LinkClicked += linkLabel4_LinkClicked;
            // 
            // linkLabel3
            // 
            linkLabel3.ActiveLinkColor = Color.MidnightBlue;
            linkLabel3.AutoSize = true;
            linkLabel3.DisabledLinkColor = Color.Black;
            linkLabel3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel3.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel3.LinkColor = Color.Black;
            linkLabel3.Location = new Point(10, 534);
            linkLabel3.MinimumSize = new Size(375, 23);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Padding = new Padding(50, 0, 0, 0);
            linkLabel3.Size = new Size(375, 23);
            linkLabel3.TabIndex = 14;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "Participant Details";
            linkLabel3.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel3.VisitedLinkColor = Color.Black;
            linkLabel3.LinkClicked += linkLabel3_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.ActiveLinkColor = Color.MidnightBlue;
            linkLabel2.AutoSize = true;
            linkLabel2.DisabledLinkColor = Color.Black;
            linkLabel2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel2.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel2.LinkColor = Color.Black;
            linkLabel2.Location = new Point(11, 400);
            linkLabel2.MinimumSize = new Size(375, 23);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Padding = new Padding(50, 0, 0, 0);
            linkLabel2.Size = new Size(375, 23);
            linkLabel2.TabIndex = 13;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Add Events";
            linkLabel2.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel2.VisitedLinkColor = Color.Black;
            linkLabel2.LinkClicked += linkLabel2_LinkClicked;
            // 
            // linkLabel1
            // 
            linkLabel1.ActiveLinkColor = Color.MidnightBlue;
            linkLabel1.AutoSize = true;
            linkLabel1.DisabledLinkColor = Color.Black;
            linkLabel1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            linkLabel1.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel1.LinkColor = Color.Black;
            linkLabel1.Location = new Point(11, 367);
            linkLabel1.MinimumSize = new Size(375, 23);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Padding = new Padding(50, 0, 0, 0);
            linkLabel1.Size = new Size(375, 23);
            linkLabel1.TabIndex = 12;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Existing Events";
            linkLabel1.TextAlign = ContentAlignment.MiddleLeft;
            linkLabel1.VisitedLinkColor = Color.Black;
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.DodgerBlue;
            label4.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(-2, 433);
            label4.MinimumSize = new Size(375, 23);
            label4.Name = "label4";
            label4.Size = new Size(375, 23);
            label4.TabIndex = 8;
            label4.Text = "Participant Registration and Fee Tracking ";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.DodgerBlue;
            label1.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(0, 326);
            label1.MinimumSize = new Size(375, 23);
            label1.Name = "label1";
            label1.Size = new Size(375, 23);
            label1.TabIndex = 5;
            label1.Text = "Event Management";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Screenshot_2025_02_24_215708;
            pictureBox1.Location = new Point(24, 25);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(307, 249);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // pnlContent
            // 
            pnlContent.AutoScroll = true;
            pnlContent.BackColor = Color.Transparent;
            pnlContent.Location = new Point(366, 1);
            pnlContent.Margin = new Padding(0);
            pnlContent.Name = "pnlContent";
            pnlContent.Size = new Size(1002, 1164);
            pnlContent.TabIndex = 5;
            // 
            // AdminDashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BackgroundImage = Properties.Resources.OIP__4_;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1353, 747);
            Controls.Add(pnlContent);
            Controls.Add(sidebrpnl);
            Name = "AdminDashboard";
            Text = "Form3";
            Load += Form3_Load;
            sidebrpnl.ResumeLayout(false);
            sidebrpnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel sidebrpnl;
        private PictureBox pictureBox1;
        private Label label1;
        private Label label5;
        private Label label8;
        private LinkLabel linkLabel1;
        private Label label4;
        private LinkLabel linkLabel4;
        private LinkLabel linkLabel3;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel5;
        private LinkLabel linkLabel9;
        private LinkLabel linkLabel8;
        private Label label2;
        private LinkLabel linkLabel12;
        private LinkLabel linkLabel10;
        private LinkLabel linkLabel7;
        private Label label3;
        private Label label7;
        private LinkLabel linkLabel13;
        private LinkLabel linkLabel16;
        private LinkLabel linkLabel14;
        private Label label9;
        private Panel pnlContent;
        private ComboBox comboBox1;
        private LinkLabel linkLabel15;
        private LinkLabel linkLabel6;
    }
}